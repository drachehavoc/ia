package ia18iniciandopoo;

import veiculos.Moto;
import veiculos.Aviao;

public class IA18IniciandoPoo {
    public static void main(String[] args) {
        Moto moto = new Moto();
        Aviao doForro = new Aviao();
        
        doForro.velocidadeMaxima = 100;
        
        System.out.println(moto.velocidadeMaxima);
        System.out.println(doForro.velocidadeMaxima);
    }    
}
