/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora.ia18.turma02.moranguinho;

/**
 *
 * @author fodasti.co
 */
public class CalculadoraIA18Turma02Moranguinho {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
