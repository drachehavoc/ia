package omentiroso;

class Mentiroso {
    private double porcentagem;
    private int idade;
    private double altura;
    private double peso;

    public Mentiroso(double paramPorcentagem, int paramIdade, double paramAltura, double paramPeso) {
        this.porcentagem = paramPorcentagem;
        this.idade = paramIdade;
        this.altura = paramAltura;
        this.peso = paramPeso;
    }
    
    public double getAltura() {
        return this.altura + (this.altura * (this.porcentagem/3));
    }
    
    public double getIdade() {
        return this.idade - (this.idade * this.porcentagem);
    }
    
    public void setPorcentagem(double paramPorcentagem) {
        if (paramPorcentagem < 0) {
            this.porcentagem = 0;
            return;
        }
        
        if (paramPorcentagem > 1) {
            this.porcentagem = 1;
            return;
        }
        
        this.porcentagem = paramPorcentagem;
    }
}

public class Programa {

    public static void main(String[] args) {
        Mentiroso politico = new Mentiroso(.9, 700, 1.7, 20);
        Janelinha plim1 = new Janelinha(politico, false);
        Janelinha plim2 = new Janelinha(politico, true);
        plim1.setVisible(true);
        plim2.setVisible(true);
    }
}
