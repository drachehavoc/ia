package estatico;

class Amor {
    public static String nome = "";
}
        
public class Estatico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Amor a = new Amor();
        Amor b = new Amor();
        Amor c = new Amor();
        Amor d = new Amor();
        Amor e = new Amor();
        Amor f = new Amor();
        
        a.nome = "Juliana";
        b.nome = "Dirce";
        c.nome = "Nirce";
        d.nome = "Joel Fortão";
        e.nome = "Kleython";
        f.nome = "Mikaela Fernanada Casagrande";
        
        System.out.println( Amor.nome );
    }
    
}
